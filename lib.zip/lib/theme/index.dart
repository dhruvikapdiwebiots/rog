import 'app_color.dart';
import 'app_css.dart';
import 'theme_service.dart';
import 'app_theme.dart';

AppColor appColor = AppColor();
AppCss appCss = AppCss();
ThemeService themeService = ThemeService();
AppTheme appTheme = AppTheme();
