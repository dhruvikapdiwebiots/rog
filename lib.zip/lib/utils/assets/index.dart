import 'image_assets.dart';
import 'icon_assets.dart';

ImageAssets imageAssets = ImageAssets();
IconAssets iconAssets = IconAssets();
