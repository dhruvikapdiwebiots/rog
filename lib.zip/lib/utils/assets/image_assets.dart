class ImageAssets {
  final String logo = 'assets/logo.png';
}
