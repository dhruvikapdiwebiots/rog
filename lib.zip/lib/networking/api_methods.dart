class ApiMethods {
  final String login = "authenticate";

}
