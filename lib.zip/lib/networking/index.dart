import 'package:rog/networking/api.dart';

import 'api_methods.dart';
import 'server_config.dart';

Apis apis = Apis();
ApiMethods apiMethods = ApiMethods();
ServerConfig serverConfig = ServerConfig();
