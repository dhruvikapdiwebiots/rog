class ServerConfig {
  final String apiUrl = "https://rog-prod.api.gorog.co/";
}
